const startBtn = document.getElementById("startBtn");
const scene = document.getElementById("scene");
const timeDisplay = document.getElementById("time");
const minutesInput = document.getElementById("minutes");

let countdown;

startBtn.addEventListener("click", () => {
    clearInterval(countdown);

    let totalSeconds = minutesInput.value * 60;

    // Start background animation
    scene.style.animationPlayState = "running";

    countdown = setInterval(() => {
        let mins = Math.floor(totalSeconds / 60);
        let secs = totalSeconds % 60;

        timeDisplay.textContent =
            String(mins).padStart(2, "0") + ":" +
            String(secs).padStart(2, "0");

        if (totalSeconds <= 0) {
            clearInterval(countdown);
            scene.style.animationPlayState = "paused";
            alert("Time's up! 🌿");
        }

        totalSeconds--;
    }, 1000);
});
const speedButtons = document.querySelectorAll(".speed-controls button");

// change background speed
speedButtons.forEach(button => {
    button.addEventListener("click", () => {
        const speed = button.getAttribute("data-speed");
        scene.style.animationDuration = speed + "s";
    });
});
